import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ParlourService } from 'src/app/services/parlour.service';

@Component({
  selector: 'app-parlour-work',
  templateUrl: './parlour-work.component.html',
  styleUrls: ['./parlour-work.component.css']
})
export class ParlourWorkComponent {
  allParlourWork: any;
  formValue!:FormGroup;
  //currency: any;
  constructor(private fb: FormBuilder, private api: ParlourService) {
  }
  ngOnInit(): void {
    this.formValue=this.fb.group({
      serviceName:[''],
      charges:['']
    })
    this.getAllParlourWork();
  }
  getAllParlourWork() {
    this.api.getAllParlourWork().subscribe((res) => {
      this.allParlourWork = res;
      console.warn(this.allParlourWork);
    })
  }

  addParlourWork(){

  }
}
