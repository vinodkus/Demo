export class Ps {
    id:number=0;
    serviceName:string='';
    charges:string='';
}
