import { Component } from '@angular/core';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { RegisterUser } from '../model/RegisterUser';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerForm!:FormGroup;
  objRegisUser:RegisterUser = new RegisterUser();
  RegisterdUserList:any;
  /**
   *
   */
  constructor(private fb:FormBuilder, private api:UserService) {  }
  ngOnInit():void{
    this.registerForm=this.fb.group({
      firstName:['',Validators.required],
      lastName:['',Validators.required],
      email:['',Validators.required],
      phone:['',Validators.required],
      password:['',Validators.required],
      confirmPassword:['',Validators.required],
      gender:['',Validators.required]
    })
    this.getAllUser();
  }

  addUser(){
    this.objRegisUser.firstName=this.registerForm.value.firstName;
    this.objRegisUser.lastName=this.registerForm.value.lastName;
    this.objRegisUser.email=this.registerForm.value.email;
    this.objRegisUser.phone=this.registerForm.value.phone;
    this.objRegisUser.password=this.registerForm.value.password;
    this.objRegisUser.confirmPassword=this.registerForm.value.confirmPassword;
    this.objRegisUser.gender=this.registerForm.value.gender;
    
    if(this.checkUniqeUser(this.objRegisUser) == false)
    {
      this.api.addUser(this.objRegisUser).subscribe((res)=>{
      
        if(res.id>0)
          alert('User added successfully');          
        this.registerForm.reset();
        this.RegisterdUserList.push(this.objRegisUser);
        //this.getAllUser();
      })
    }
    else
    {
      alert('User already exists');
    } 
    

  }
  getAllUser(){
    this.api.getAllUser().subscribe((res)=>{
      this.RegisterdUserList=res;
    })
  }
  checkUniqeUser(regisUser:RegisterUser):boolean{
    let userExist = false;
    for(let i=0; i<this.RegisterdUserList.length;i++)
      {
        if(this.RegisterdUserList[i].email==regisUser.email)
        {
          userExist=true;
        }
      }
   
    return userExist;
  }
}
