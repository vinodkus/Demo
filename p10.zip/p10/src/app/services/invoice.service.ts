import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InvoiceService {

  constructor(private http:HttpClient) { }
  GetCustomer(){
    return this.http.get('http://localhost:3000/CustomerList')
  }
  GetCustomerByCode(code:any){
    return this.http.get('http://localhost:3000/GetCustomerByCode?code='+code)
  }
  GetProducts(){
    return this.http.get('http://localhost:3000/ParlourServices')
  }
  GetProductByCode(code:any){
    return this.http.get('http://localhost:3000/ParlourServiceByCode?Code='+code)
  }
}
