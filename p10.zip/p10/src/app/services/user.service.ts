import { HttpClient } from '@angular/common/http';
import { APP_ID, Injectable } from '@angular/core';
import {map} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  addUser(data:any)
  {    
    return this.http.post('http://localhost:3000/UserList',data).pipe(map((res:any)=>{
      return res;
    }))
  }

  // getUserByEmailId(email:string){
  //   return this.http.get('http://localhost:3000/UserList?email='+email).pipe(map((res:any)=>{
  //     console.log('service '+ res.email)
  //     return res.email;
  //   }))
  // }
  getAllUser(){
    return this.http.get('http://localhost:3000/UserList').pipe((res:any)=>{
      return res;
    })
  }
  
}
