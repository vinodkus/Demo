import { Component } from '@angular/core';
import { Form, FormArray, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { InvoiceService } from 'src/app/services/invoice.service';

@Component({
  selector: 'app-create-invoice',
  templateUrl: './create-invoice.component.html',
  styleUrls: ['./create-invoice.component.css']
})
export class CreateInvoiceComponent {
  pagetitle: string = '';
  invoicedetail!:FormArray<any>;
  constructor(private builder: FormBuilder, private _invService:InvoiceService, private router:Router) {
    this.pagetitle = 'Create Invoice';
  }
  ngOnInit():void{}
  invoiceform=this.builder.group({
    invoiceNo:this.builder.control('',Validators.required),
    customerId:this.builder.control('',Validators.required),
    customerName:this.builder.control(''),
    deliveryAddress:this.builder.control(''),
    remarks:this.builder.control(''),
    total:this.builder.control(''),
    tax:this.builder.control(''),
    netTotal:this.builder.control(''),
    details:this.builder.array([])

  });
  SaveInvoice(){
    console.log(this.invoiceform.value);
  }
  addnewproduct(){
this.invoicedetail=this.invoiceform.get("details") as FormArray;
this.invoicedetail.push(this.Generaterow());
  }
get invoiceproducts(){
  return this.invoiceform.get("details") as FormArray;
}
  Generaterow(){
    return this.builder.group({
      invoiceNo:this.builder.control(''),
      productCode:this.builder.control('',Validators.required),
      productName:this.builder.control(''),
      qty:this.builder.control(1),
      salesPrice:this.builder.control(0),
      total:this.builder.control({value:0,disabled:true})
    })
  }
}
