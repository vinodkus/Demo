import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ParlourService } from 'src/app/services/parlour.service';
import { Ps } from '../model/ps';

@Component({
  selector: 'app-parlour-work',
  templateUrl: './parlour-work.component.html',
  styleUrls: ['./parlour-work.component.css']
})
export class ParlourWorkComponent {
  searchText:string='';
  allParlourWork: any;
  showEdit:boolean=false;
  editedId:number=0;  
  formValue!: FormGroup;
  PsModelObj: Ps = new Ps();
  totalLength:any;
  page:number=1;
  //currency: any;
  constructor(private fb: FormBuilder, private api: ParlourService) {
  }

  ngOnInit(): void {
    this.formValue = this.fb.group({
      serviceName: [''],
      price: [''],
      duration: [''],
      desc: [''],
    })
    this.getAllParlourWork();
  }
  showEditForm(data:any){
    console.log(data.id);
    this.editedId = data.id;
    this.showEdit=true;
   // this.formValue.value.serviceName=data.serviceName;
    this.formValue = this.fb.group({
      serviceName: [data.serviceName],
      price: [data.price],
      duration: [data.duration],
      desc: [data.desc],
    })
   // this.PsModelObj.serviceName=data.serviceName;
  }
  getAllParlourWork() {
    this.api.getAllParlourWork().subscribe((res) => {
      this.allParlourWork = res;
      this.totalLength=res.length;
      console.warn(this.allParlourWork);
    })
  }
  openService(){
    this.showEdit=false;
    this.formValue = this.fb.group({
      serviceName: [''],
      price: [''],
      duration: [''],
      desc: [''],
    })
  }
  addParlourWork() {
    this.PsModelObj.serviceName = this.formValue.value.serviceName;
    this.PsModelObj.price = this.formValue.value.price;
    this.PsModelObj.duration = this.formValue.value.duration;
    this.PsModelObj.desc = this.formValue.value.desc;
    this.api.addParolurWork(this.PsModelObj).subscribe((res) => {
      console.log(res);
      alert('Record added successfully');
      let ref = document.getElementById('close');
      ref?.click();
      this.formValue.reset();
      this.getAllParlourWork();
    })   
  }
  updateParlourWork(){
    // this.PsModelObj.id = this.formValue.value.id;
     this.PsModelObj.serviceName = this.formValue.value.serviceName;
     this.PsModelObj.price = this.formValue.value.price;
     this.PsModelObj.duration = this.formValue.value.duration;
     this.PsModelObj.desc = this.formValue.value.desc;
  return this.api.updateParlourWork(this.PsModelObj,this.editedId).subscribe((res)=>{
   alert('updated');
   let ref = document.getElementById('close');
   ref?.click();
   this.getAllParlourWork();
  })
 }
  delParlourWork(data:any){
    alert('data '+data.id)
    this.api.deleteParlourWork(data.id).subscribe((res)=>{
      alert('deleted');
      this.getAllParlourWork();
    })
  }


}
