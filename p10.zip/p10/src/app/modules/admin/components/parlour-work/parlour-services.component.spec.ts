import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParlourServicesComponent } from './parlour-work.component';

describe('ParlourServicesComponent', () => {
  let component: ParlourServicesComponent;
  let fixture: ComponentFixture<ParlourServicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParlourServicesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ParlourServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
