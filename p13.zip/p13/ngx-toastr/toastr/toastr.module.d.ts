import { ModuleWithProviders } from '@angular/core';
import { GlobalConfig } from './toastr-config';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './toast.component';
import * as ɵngcc2 from '@angular/common';
export declare const DefaultGlobalConfig: GlobalConfig;
export declare class ToastrModule {
    static forRoot(config?: Partial<GlobalConfig>): ModuleWithProviders<ToastrModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<ToastrModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<ToastrModule, [typeof ɵngcc1.Toast], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.Toast]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<ToastrModule>;
}
export declare class ToastrComponentlessModule {
    static forRoot(config?: Partial<GlobalConfig>): ModuleWithProviders<ToastrModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<ToastrComponentlessModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<ToastrComponentlessModule, never, [typeof ɵngcc2.CommonModule], never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<ToastrComponentlessModule>;
}

//# sourceMappingURL=toastr.module.d.ts.map