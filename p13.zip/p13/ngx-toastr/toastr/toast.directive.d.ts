import { ElementRef } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class ToastContainerDirective {
    private el;
    constructor(el: ElementRef);
    getContainerElement(): HTMLElement;
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<ToastContainerDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDeclaration<ToastContainerDirective, "[toastContainer]", ["toastContainer"], {}, {}, never, never, false>;
}
export declare class ToastContainerModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<ToastContainerModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<ToastContainerModule, [typeof ToastContainerDirective], never, [typeof ToastContainerDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<ToastContainerModule>;
}

//# sourceMappingURL=toast.directive.d.ts.map