import { Component } from '@angular/core';
import { Form, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { InvoiceService } from 'src/app/services/invoice.service';
import{CustomerService} from 'src/app/services/customer.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-create-invoice',
  templateUrl: './create-invoice.component.html',
  styleUrls: ['./create-invoice.component.css']
})
export class CreateInvoiceComponent {
  ps:any;
  pagetitle: string = '';
  invoicedetail!: FormArray<any>;
  invoiceproduct!:FormGroup<any>;
  mastercustomer: any;
  masterproduct: any;
  constructor(private builder: FormBuilder, private _invService: InvoiceService, private _customerService: CustomerService, private router: Router
    ,private alert: ToastrService
    ) {
    this.pagetitle = 'Create Invoice';
  }
  ngOnInit(): void { 
this.getCustomers();
this.getProducts();
  }
  invoiceform = this.builder.group({
    invoiceNo: this.builder.control('', Validators.required),
    customerId: this.builder.control('', Validators.required),
    customerName: this.builder.control(''),
    deliveryAddress: this.builder.control(''),
    remarks: this.builder.control(''),
    total: this.builder.control(''),
    tax: this.builder.control(''),
    netTotal: this.builder.control(''),
    details: this.builder.array([])

  });
  SaveInvoice() {
    console.log(this.invoiceform.value);
  }
  addnewproduct() {
    this.invoicedetail = this.invoiceform.get("details") as FormArray;
    let customerCode = this.invoiceform.get("customerId")?.value;
    if(customerCode != '' && customerCode != null)
    {
      this.invoicedetail.push(this.Generaterow());
    }
    else
    {
      this.alert.error("Please select customer","Validation");
    }
    
   
    
  }
  get invoiceproducts() {
    return this.invoiceform.get("details") as FormArray;
  }
  Generaterow() {
    return this.builder.group({
      invoiceNo: this.builder.control(''),
      serviceName: this.builder.control('', Validators.required),
     // id: this.builder.control('',Validators.required),
      desc: this.builder.control(''),
      qty: this.builder.control(1),
      salesPrice: this.builder.control(0),
      total: this.builder.control({ value: 0, disabled: true })
    })
  }
  changeCustomer(){
    let customerCode = this.invoiceform.get("customerId")?.value;
    this._customerService.getCustomerByCode(customerCode).subscribe(res=>{
      console.log(res);
      let custdata=res;
      this.invoiceform.get("deliveryAddress")?.setValue(custdata.address)
    })
    console.log('customerCode '+ customerCode);
  }
  getCustomers(){
    this._invService.GetCustomer().subscribe(res=>{
      this.mastercustomer = res;
    })
  }

  getProducts(){
    this._invService.GetProducts().subscribe(res=>{
      this.masterproduct=res;
    })
  }
  changeService(index:any){
    this.invoicedetail = this.invoiceform.get("details") as FormArray;
    this.invoiceproduct=this.invoicedetail.at(index) as FormGroup;
    let serviceId=this.invoiceproduct.value.serviceName;
    console.log('this.invoiceproduct '+ serviceId);
    this._invService.GetProductByCode(serviceId).subscribe(res=>{
      let serviceData:any;
      serviceData=res;
      if(serviceData!= null)
      {
        this.invoiceproduct.get("desc")?.setValue(serviceData.desc);
        this.invoiceproduct.get("salesPrice")?.setValue(serviceData.price);
        this.ItemCalculation(index);
      }
    })

  }

  ItemCalculation(index:any){
    this.invoicedetail = this.invoiceform.get("details") as FormArray;
    this.invoiceproduct=this.invoicedetail.at(index) as FormGroup;
    let qty = this.invoiceproduct.get("qty")?.value;
    let price = this.invoiceproduct.get("salesPrice")?.value;
    let total = qty*price;
    this.invoiceproduct.get("total")?.setValue(total);
    this.SummaryCalculation();
  }

  SummaryCalculation(){
   let array= this.invoiceform.getRawValue().details;
   let sumtotal=0;
   //console.log(array);
   array.forEach((x:any)=>{
    sumtotal = sumtotal+x.total;
   })
   let sumtax=sumtotal*(7/100);
   let nettotal = sumtotal+sumtax;
   console.log("sumtotal "+sumtotal);
   this.invoiceform.get("total")?.setValue(String(sumtotal));
   this.invoiceform.get("tax")?.setValue(String(sumtax));
   this.invoiceform.get("netTotal")?.setValue(String(nettotal));
  }
}
