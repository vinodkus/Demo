# ngx-pagination

The simplest solution for pagination in Angular.

## Demo

Check out the live demo here: http://michaelbromley.github.io/ngx-pagination/

Play with it on StackBlitz here: https://stackblitz.com/edit/angular-e1f9hq

## Documentation

For full documentation, see https://github.com/michaelbromley/ngx-pagination/blob/master/README.md
