export * from './lib/paginate.pipe';
export * from './lib/pagination.service';
export * from './lib/pagination-controls.component';
export * from './lib/pagination-controls.directive';
export * from './lib/pagination-instance';
export * from './lib/ngx-pagination.module';
