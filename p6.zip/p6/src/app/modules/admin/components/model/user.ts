export class User {
    id:number=0;
    fullName:string='';
    avatar:string='';
    userName:string='';
    password:string='';
    contact:string='';
    email:string='';
    status:number=0;
}
