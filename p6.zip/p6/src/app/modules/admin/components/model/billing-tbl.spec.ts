import { BillingTbl } from './billing-tbl';

describe('BillingTbl', () => {
  it('should create an instance', () => {
    expect(new BillingTbl()).toBeTruthy();
  });
});
