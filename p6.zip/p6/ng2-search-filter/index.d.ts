export * from './src/ng2-filter.module';
export * from './src/ng2-filter.pipe';
