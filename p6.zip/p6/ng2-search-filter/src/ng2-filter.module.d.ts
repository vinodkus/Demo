import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './ng2-filter.pipe';
export declare class Ng2SearchPipeModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<Ng2SearchPipeModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<Ng2SearchPipeModule, [typeof ɵngcc1.Ng2SearchPipe], never, [typeof ɵngcc1.Ng2SearchPipe]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<Ng2SearchPipeModule>;
}

//# sourceMappingURL=ng2-filter.module.d.ts.map