/**
 * Generated bundle index. Do not edit.
 */
export * from './index';

//# sourceMappingURL=ng2-search-filter.d.ts.map