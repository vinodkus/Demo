import { Component } from '@angular/core';
import { InvoiceService } from 'src/app/services/invoice.service';


@Component({
  selector: 'app-invoice-list',
  templateUrl: './invoice-list.component.html',
  styleUrls: ['./invoice-list.component.css']
})
export class InvoiceListComponent {
InvoiceHeader:any;
searchText:string='';
totalLength:any;
page:number=1;
constructor( private _invService: InvoiceService) {

}
ngOnInit():void{
  this.LoadInvoice();
}
LoadInvoice(){
this._invService.GetAllInvoice().subscribe(res=>{
  this.InvoiceHeader=res;
})
}
}
