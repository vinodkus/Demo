import { BillingDtl } from './billing-dtl';

describe('BillingDtl', () => {
  it('should create an instance', () => {
    expect(new BillingDtl()).toBeTruthy();
  });
});
