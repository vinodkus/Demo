import { TestBed } from '@angular/core/testing';

import { ParlorWorkService } from './parlour-work.service';

describe('ParlorWorkService', () => {
  let service: ParlorWorkService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ParlorWorkService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
