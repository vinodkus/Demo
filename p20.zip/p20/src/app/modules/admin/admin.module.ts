import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { LeftPanelComponent } from './components/left-panel/left-panel.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ProductComponent } from './components/product/product.component';
import { InvoiceListComponent } from './components/invoice-list/invoice-list.component';
import { CreateInvoiceComponent } from './components/create-invoice/create-invoice.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgxPaginationModule } from 'ngx-pagination';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';

@NgModule({
  declarations: [
    AdminDashboardComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    LeftPanelComponent,
    ProductComponent,
   InvoiceListComponent,
   CreateInvoiceComponent,
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    FormsModule,
    ReactiveFormsModule ,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    AutocompleteLibModule

  ]
})
export class AdminModule { }
