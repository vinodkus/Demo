export class Ps {
    id:number=0;
    serviceName:string='';
    price:string='';
    duration:string='';
    desc:string='';
    
}
