import { Ps } from './ps';

describe('Ps', () => {
  it('should create an instance', () => {
    expect(new Ps()).toBeTruthy();
  });
});
