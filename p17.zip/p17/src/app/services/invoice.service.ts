import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InvoiceService {

  constructor(private http:HttpClient) { }
  GetCustomer(){
    return this.http.get('http://localhost:3000/CustomerList');
  }
  GetCustomerByCode(code:any){
   
    
  }
  GetProducts(){
    return this.http.get('http://localhost:3000/ParlourServices');
  }
  GetProductByCode(code:any){
    var result;
    return this.http.get('http://localhost:3000/ParlourServices/'+code);
  }
  SaveInvoice(invoiceData:any){
    return this.http.post('http://localhost:3000/Invoices',invoiceData)
  }
  GetAllInvoice(){
    return this.http.get('http://localhost:3000/Invoices');
  }

  DeleteInvoice(code:any){
    return this.http.delete('http://localhost:3000/Invoices/'+code);
  }

  GetInvoiceHeaderById(code:any){
    return this.http.get('http://localhost:3000/Invoices/'+code);
  }
  GetInvoiceDetailsById(code:any){
    return this.http.get('http://localhost:3000/Invoices/'+code).subscribe(x=>{
      let dtl:any;
      
    })
  }
}
  