import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CustomerService } from 'src/app/services/customer.service';
import { Customer } from '../model/customer';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent  {
allCustomers:any;
showEdit:boolean=false;
editedId:number=0;
customerForm!:FormGroup;
csObj:Customer = new Customer();
totalLength:any;
page:number=1;
  constructor(private fb:FormBuilder, private api:CustomerService) { }

  ngOnInit(): void {
    this.customerForm=this.fb.group({
      fullName:[''],
      email:[''],
      contact:[''],
      address:[''],
      tower:[''],
      society:['']
    })
    this.getAllCustomer();
  }
  showEditForm(data:any){
    this.showEdit=true;
    this.editedId=data.id;
    this.customerForm=this.fb.group({
      fullName:[data.fullName],
      email:[data.email],
      contact:[data.contact],
      address:[data.address],
      tower:[data.tower],
      society:[data.society]
    })
  }
  getAllCustomer(){
    this.api.getAllCustomer().subscribe((res)=>{
      //debugger;
      this.allCustomers = res;
      this.totalLength=res.length;
      //console.warn(this.allCustomers);
    })
  }
 
  openCustomerPopUp(){    
    this.showEdit=false;
    this.customerForm=this.fb.group({
      fullName:[''],
      email:[''],
      contact:[''],
      address:[''],
      tower:[''],
      society:['']
    })
  }

  addCustomer(){
    this.csObj.fullName=this.customerForm.value.fullName;
    this.csObj.address = this.customerForm.value.address;
    this.csObj.contact=this.customerForm.value.contact;
    this.csObj.email=this.customerForm.value.email;
    this.csObj.society=this.customerForm.value.society;
    this.csObj.tower=this.customerForm.value.tower;
    this.api.addCustomer(this.csObj).subscribe((res)=>{
      let ref=document.getElementById('close');
      ref?.click();
      this.customerForm.reset();
      this.getAllCustomer();
    })
  }
  updateCustomer(){
    
    this.csObj.fullName=this.customerForm.value.fullName;
    this.csObj.address = this.customerForm.value.address;
    this.csObj.contact=this.customerForm.value.contact;
    this.csObj.email=this.customerForm.value.email;
    this.csObj.society=this.customerForm.value.society;
    this.csObj.tower=this.customerForm.value.tower;
    this.api.updateCustomer(this.csObj,this.editedId).subscribe((res)=>{
      this.getAllCustomer();
      let ref = document.getElementById('close');
      ref?.click();
      alert('updated');
    })
  }

  delCustomer(data:any){
    this.api.deleteCustomer(data.id).subscribe((res)=>{     
      this.getAllCustomer();
      alert('customer deleted successfully');
    })
  }

}
