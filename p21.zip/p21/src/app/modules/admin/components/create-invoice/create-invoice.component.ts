import { Component } from '@angular/core';
import { Form, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { InvoiceService } from 'src/app/services/invoice.service';
import { CustomerService } from 'src/app/services/customer.service';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common'

@Component({
  selector: 'app-create-invoice',
  templateUrl: './create-invoice.component.html',
  styleUrls: ['./create-invoice.component.css']
})
export class CreateInvoiceComponent {
  keyword = 'name';
  ps: any;
  pagetitle: string = 'Create Invoice';
  invoicedetail!: FormArray<any>;
  invoiceproduct!: FormGroup<any>;
  mastercustomer: any;
  masterproduct: any;
  editInvoiceId: any;
  editInvDetails: any;
  isedit = false;
  constructor(private builder: FormBuilder, public datepipe: DatePipe, private _invService: InvoiceService, private _customerService: CustomerService, private router: Router
    , private alert: ToastrService, private activeroute: ActivatedRoute
  ) {
    this.pagetitle = 'Create Invoice';
  }
  ngOnInit(): void {
    this.getCustomers();
    this.getProducts();
    this.editInvoiceId = this.activeroute.snapshot.paramMap.get('invid')
    if (this.editInvoiceId != null) {
      this.pagetitle = "Edit Invoice";
      this.isedit = true;
      this.setEditInfo(this.editInvoiceId);
    }
  }
  setEditInfo(invId: any) {
    debugger;
    let editInvDetails: any;
    this._invService.GetInvoiceHeaderById(invId).subscribe(res => {

      editInvDetails = res;
      //  debugger;
      this.invoicedetail = this.invoiceform.get("details") as FormArray;
      // debugger;
      for (let i = 0; i < editInvDetails.details.length; i++) {
        this.addnewproduct();
        // debugger;
      }
    })
    this._invService.GetInvoiceHeaderById(invId).subscribe(res => {
      // debugger;
      let editData: any;
      editData = res;
      if (editData != null) {
        this.invoiceform.setValue(editData);
      }
    })
  }
  invoiceform = this.builder.group({
    id: this.builder.control(''),
    invoiceNo: this.builder.control(''),
    customerId: this.builder.control('', Validators.required),
    customerName: this.builder.control(''),
    deliveryAddress: this.builder.control(''),
    remarks: this.builder.control(''),
    invoiceDate: this.builder.control(''),
    total: this.builder.control('0'),
    tax: this.builder.control('0'),
    grossTotal: this.builder.control('0'),
    netTotal: this.builder.control('0'),
    balance: this.builder.control('0'),
    amtpay: this.builder.control('0'),
    // totalAmtPaid: this.builder.control('0'),    
    discount: this.builder.control('0'),
    details: this.builder.array([])

  });
  SaveInvoice() {
    debugger;
    let nettotal: any;
    let amtpay: any;
    let balance: any;
    if (this.invoiceform.getRawValue().details.length > 0) {
      if (this.invoiceform.valid) {

        console.log(this.invoiceform.getRawValue());
        let inv = this.invoiceform.getRawValue();
        console.log(inv);
        if (this.invoiceform.getRawValue().invoiceDate == '') {
          var dt = new Date();
          let latest_date = this.datepipe.transform(dt, 'yyyy-MM-dd');
          this.invoiceform.get('invoiceDate')?.setValue(latest_date)
        }
        debugger;
        if (this.isedit == false) {
          this._invService.SaveInvoice(this.invoiceform.getRawValue()).subscribe(res => {
            let d: any;
            d = res;
            var invId = d.id;
            // debugger;
            console.log('saveInvoice: ' + invId);
            let invno: string;
            invno = 'GLM-' + invId;
            this.invoiceform.get('invoiceNo')?.setValue(invno);

            //   let totalAmtPaid:any;
            balance = this.invoiceform.get("balance")?.value;
            amtpay = this.invoiceform.get("amtpay")?.value;
            //  totalAmtPaid = this.invoiceform.get("totalAmtPaid")?.value;
            //  totalAmtPaid =parseInt(totalAmtPaid)  +parseInt(amtpay) ;
            //   this.invoiceform.get("totalAmtPaid")?.setValue(totalAmtPaid);
            balance = parseInt(balance) - parseInt(amtpay);
            if (balance >= 0) {
              this.invoiceform.get("balance")?.setValue(balance);
              this.invoiceform.get("amtpay")?.setValue('0');
              if (invno.length > 0) {
                this._invService.UpdateInvoice(this.invoiceform.getRawValue(), invId).subscribe(res => {
                  let d: any;
                  d = res;
                  var invId = d.id;
                  //  debugger;     
                  if (res != null) {
                    this.alert.success('Invoice submitted successfully', 'Invoice');
                    this.router.navigate(['/admin/invoicelist']);
                  }
                })
              }
            }
            else {
              this.alert.warning('Amount to pay should not be greater than balance');
            }
            // debugger;
            
          })
        }
        else {
          if (this.isedit) {
            balance = this.invoiceform.get("balance")?.value;
            amtpay = this.invoiceform.get("amtpay")?.value;
            balance = parseInt(balance) - parseInt(amtpay);
            if (balance >= 0) {
              this.invoiceform.get("balance")?.setValue(balance);
              this.invoiceform.get("amtpay")?.setValue('0');
              this._invService.UpdateInvoice(this.invoiceform.getRawValue(), this.editInvoiceId).subscribe(res => {
                let d: any;
                debugger;
                d = res;
                var invId = d.id;
                //  debugger;
  
                if (res != null) {
                  this.alert.success('Invoice updated successfully', 'Invoice');
                  this.router.navigate(['/admin/invoicelist']);
                }
              })
            }
            else {
              this.alert.warning('Amount to pay should not be greater than balance');
            }
          }
          
        }

      }
      else {
        this.alert.warning('Please fill all mandatory field', 'Validation');
      }
    }
    else {
      this.alert.warning('Please add service details', 'Validation');
    }

  }
  addnewproduct() {
    this.invoicedetail = this.invoiceform.get("details") as FormArray;
    let customerCode = this.invoiceform.get("customerId")?.value;
    if ((customerCode != '' && customerCode != null) || this.isedit) {
      this.invoicedetail.push(this.Generaterow());
    }
    else {
      this.alert.warning("Please select customer", "Validation");
    }
  }
  get invoiceproducts() {
    return this.invoiceform.get("details") as FormArray;
  }
  Generaterow() {
    return this.builder.group({
      invoiceNo: this.builder.control(''),
      serviceName: this.builder.control({ value: '', disabled: this.isedit }, Validators.required),
      desc: this.builder.control({ value: '', disabled: this.isedit }),
      qty: this.builder.control({ value: 1, disabled: this.isedit }),
      salesPrice: this.builder.control({ value: 0, disabled: this.isedit }),
      total: this.builder.control({ value: 0, disabled: true })
    })
  }
  changeCustomer() {
    // debugger;
    let customerCode = this.invoiceform.get("customerId")?.value;
    this._customerService.getCustomerByCode(customerCode).subscribe(res => {
      console.log(res);
      let custdata = res;
      this.invoiceform.get("deliveryAddress")?.setValue(custdata.address);
      this.invoiceform.get("customerName")?.setValue(custdata.fullName);
    })
    console.log('customerCode ' + customerCode);
  }
  getCustomers() {
    this._invService.GetCustomer().subscribe(res => {
      this.mastercustomer = res;
    })
  }

  getProducts() {
    this._invService.GetProducts().subscribe(res => {
      this.masterproduct = res;
    })
  }
  changeService(index: any) {
    if (!this.isedit) {
      this.invoicedetail = this.invoiceform.get("details") as FormArray;
      this.invoiceproduct = this.invoicedetail.at(index) as FormGroup;
      let serviceId = this.invoiceproduct.value.serviceName;
      console.log('this.invoiceproduct ' + serviceId);
      this._invService.GetProductByCode(serviceId).subscribe(res => {
        let serviceData: any;
        serviceData = res;
        if (serviceData != null) {
          this.invoiceproduct.get("desc")?.setValue(serviceData.desc);
          this.invoiceproduct.get("salesPrice")?.setValue(serviceData.price);
          this.ItemCalculation(index);
        }
        this.SetDiscount();
      })

    }
    else {
      this.alert.warning('New service can not be add with old invoice');
    }



  }

  ItemCalculation(index: any) {
    this.invoicedetail = this.invoiceform.get("details") as FormArray;
    this.invoiceproduct = this.invoicedetail.at(index) as FormGroup;
    let qty = this.invoiceproduct.get("qty")?.value;
    let price = this.invoiceproduct.get("salesPrice")?.value;
    let total = qty * price;
    this.invoiceproduct.get("total")?.setValue(total);
    this.SummaryCalculation();
    this.SetDiscount();

  }

  SummaryCalculation() {
    debugger;
    let array = this.invoiceform.getRawValue().details;
    let sumtotal = 0;
    let discount: any;
    let tax: any;
    discount = this.invoiceform.get("discount")?.value;
    tax = this.invoiceform.get("tax")?.value;
    array.forEach((x: any) => {
      sumtotal = sumtotal + x.total;
    })
    let sumtax = sumtotal * (tax / 100);
    let nettotal = (sumtotal + sumtax) - discount;
    console.log("sumtotal " + sumtotal);
    this.invoiceform.get("total")?.setValue(String(sumtotal));
    this.invoiceform.get("netTotal")?.setValue(String(nettotal));
  }
  ChangeTax() {
    this.SetDiscount();
  }
  SetDiscount() {
    debugger;
    let discount: any;
    let nettotal: any;
    let sumtotal: any;
    let balance: any;
    let tax: any;
    let grossTotal: any;
    discount = this.invoiceform.get("discount")?.value;
    sumtotal = this.invoiceform.get("total")?.value;
    // balance = this.invoiceform.get("balance")?.value;
    tax = this.invoiceform.get("tax")?.value;
    let sumtax = sumtotal * (tax / 100);
    //grossTotal
    grossTotal = parseInt(sumtotal) + sumtax;
    this.invoiceform.get("grossTotal")?.setValue(String(grossTotal));
    nettotal = (parseInt(sumtotal) + sumtax) - parseInt(discount);
    this.invoiceform.get("netTotal")?.setValue(nettotal);
    if (!this.isedit) {
      this.invoiceform.get("balance")?.setValue(nettotal);
      //  this.invoiceform.get("totalAmtPaid")?.setValue('0');

    }
    // this.invoiceform.get("balance")?.setValue(balance);
  }
  RemoveService(index: any) {

    if (confirm('Do you want to remove this service')) {
      this.invoicedetail = this.invoiceform.get("details") as FormArray;
      //this.invoiceproduct=this.invoicedetail.at(index) as FormGroup;
      this.invoicedetail.removeAt(index);
      this.SummaryCalculation();
      this.SetDiscount();
    }
  }
 
}
