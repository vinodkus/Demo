export class BillingTbl {
    id:number=0;
    billingNumber:number=0;
    billAmount:number=0;
    customerId:number=0;
    dateofbilling:string='';
    userid:number=0;
}
