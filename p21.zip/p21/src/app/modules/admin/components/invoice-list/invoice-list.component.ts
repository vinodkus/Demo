import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { InvoiceService } from 'src/app/services/invoice.service';


@Component({
  selector: 'app-invoice-list',
  templateUrl: './invoice-list.component.html',
  styleUrls: ['./invoice-list.component.css']
})
export class InvoiceListComponent {
  InvoiceHeader: any;
  searchText: string = '';
  totalLength: any;
  page: number = 1;
  InvoiceDetail: any;
  order: any;
  isDesc:any;

  constructor(private _invService: InvoiceService, private router: Router) {

  }
  ngOnInit(): void {
    this.LoadInvoice();
  }
  LoadInvoice() {
    this._invService.GetAllInvoice().subscribe(res => {
      this.InvoiceHeader = res;
    })
  }
  deleteInvoice(code: any) {
    if (confirm('Do you want to remove this invoice')) {
      this._invService.DeleteInvoice(code).subscribe(res => {
        this.LoadInvoice();
      })
    }
  }

  EditInvoice(code: any) {
    this.router.navigateByUrl('/admin/editinvoice/' + code)
    this._invService.GetInvoiceHeaderById(code).subscribe(res => {
      this.InvoiceDetail = res;
    })
  }
  SortNettotal(){
    if (this.order) {
      let newArr = this.InvoiceHeader.sort((a: { netTotal: number; }, b: { netTotal: number; }) => a.netTotal - b.netTotal);
      this.InvoiceHeader = newArr;
    }
    else {
      let newArr = this.InvoiceHeader.sort((a: { netTotal: number; }, b: { netTotal: number; }) => b.netTotal - a.netTotal);
      this.InvoiceHeader = newArr;
    }
    this.order = !this.order;

  }
 
  SortBalance() {
    if (this.order) {
      let newArr = this.InvoiceHeader.sort((a: { balance: number; }, b: { balance: number; }) => a.balance - b.balance);
      this.InvoiceHeader = newArr;
    }
    else {
      let newArr = this.InvoiceHeader.sort((a: { balance: number; }, b: { balance: number; }) => b.balance - a.balance);
      this.InvoiceHeader = newArr;
    }
    this.order = !this.order;

  }

  SortName(property:string){
  this.isDesc = !this.isDesc;
  let direction = this.isDesc ?1:-1;
  this.InvoiceHeader.sort(function(a: { [x: string]: number; },b: { [x: string]: number; }){
   if(a[property]<b[property])
   {
    return -1*direction;
   }
   else if(a[property]>b[property])
   {
    return 1*direction;
   }
   else
   {
    return 0;
   }
  })
  }
}
