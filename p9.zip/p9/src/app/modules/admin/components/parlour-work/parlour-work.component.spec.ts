import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParlourWorkComponent } from './parlour-work.component';

describe('ParlourServiceComponent', () => {
  let component: ParlourWorkComponent;
  let fixture: ComponentFixture<ParlourWorkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParlourWorkComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ParlourWorkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
