import { HttpClient } from '@angular/common/http';
import { identifierName } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  constructor(private http: HttpClient) { }
  addCustomer(data: any) {
    console.log(data)
    return this.http.post('http://localhost:3000/CustomerList', data).pipe(map((res: any) => {
      return res;
    }))
  }

  getAllCustomer(){
    return this.http.get('http://localhost:3000/CustomerList').pipe(map((res:any)=>{
      return res;
    }))
  }

  updateCustomer(data:any, id:number){
    console.log('api update '+data);
    console.log('id '+id);
    return this.http.put('http://localhost:3000/CustomerList/'+id,data).pipe(
      map((res:any)=>{
      return res;
    }))
  }

    deleteCustomer(id:number){
     // alert('apid del id '+id);
      return this.http.delete('http://localhost:3000/CustomerList/'+id).pipe(
        map((res:any)=>{
          return res;
        }))
    }
  
}
