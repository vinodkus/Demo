export class Customer {
    id:number=0;
    FullName:string='';
    email:string='';
    contact:string='';
    username:string='';
    password:string='';
}
