import { HttpClient } from '@angular/common/http';
import { identifierName } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ParlourService {

  constructor(private http: HttpClient) { }
  addParolurWork(data: any) {
    return this.http.post('http://localhost:3000/ParlourServices', data).pipe(map((res: any) => {
      return res;
    }))
  }

  getAllParlourWork(){
    return this.http.get('http://localhost:3000/ParlourServices').pipe(map((res:any)=>{
      return res;
    }))
  }

  updateParlourWork(data:any, id:number){
    console.log('api update '+data);
    console.log('id '+id);
    return this.http.put('http://localhost:3000/ParlourServices/'+id,data).pipe(
      map((res:any)=>{
      return res;
    }))
  }

    deleteParlourWork(id:number){
     // alert('apid del id '+id);
      return this.http.delete('http://localhost:3000/ParlourServices/'+id).pipe(
        map((res:any)=>{
          return res;
        }))
    }
  
}
