export class Customer {
    id:number=0;
    fullName:string='';
    email:string='';
    contact:string='';
    address:string='';
    tower:string='';
    society:string='';
}
