import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CustomerService } from 'src/app/services/customer.service';
import { Customer } from '../model/customer';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
allCustomers:any;
showEdit:boolean=false;
customerForm!:FormGroup;
  constructor(private fb:FormBuilder, private api:CustomerService) { }

  ngOnInit(): void {
    this.customerForm=this.fb.group({
      fullName:[''],
      email:[''],
      contact:[''],
      address:[''],
      tower:[''],
      society:['']
    })
    this.getAllCustomer();
  }
  getAllCustomer(){
    this.api.getAllCustomer().subscribe((res)=>{
      //debugger;
      this.allCustomers = res;
      //console.warn(this.allCustomers);
    })
  }
  showEditForm(data:any){}
  addCustomer(){}
  updateCustomer(){}
  openCustomerPopUp(){
    this.showEdit=false;
  }
  delCustomer(data:any){}

}
