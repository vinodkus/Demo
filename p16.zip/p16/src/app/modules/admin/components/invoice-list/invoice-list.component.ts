import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { InvoiceService } from 'src/app/services/invoice.service';


@Component({
  selector: 'app-invoice-list',
  templateUrl: './invoice-list.component.html',
  styleUrls: ['./invoice-list.component.css']
})
export class InvoiceListComponent {
InvoiceHeader:any;
searchText:string='';
totalLength:any;
page:number=1;
InvoiceDetail:any;
constructor( private _invService: InvoiceService,private router:Router) {

}
ngOnInit():void{
  this.LoadInvoice();
}
LoadInvoice(){
this._invService.GetAllInvoice().subscribe(res=>{
  this.InvoiceHeader=res;
})
}
deleteInvoice(code:any){
  if(confirm('Do you want to remove this invoice'))
    {
  this._invService.DeleteInvoice(code).subscribe(res=>{
    this.LoadInvoice();
  })
}
}

EditInvoice(code:any){
this.router.navigateByUrl('/admin/editinvoice/'+code)
  this._invService.GetInvoiceById(code).subscribe(res=>{
    this.InvoiceDetail = res;
  })
}
}
