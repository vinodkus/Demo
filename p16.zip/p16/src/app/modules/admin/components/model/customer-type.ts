export class CustomerType {
    id:number=0;
    type:string='';
}
