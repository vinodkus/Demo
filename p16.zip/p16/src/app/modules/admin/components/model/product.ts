export class Product {
    productName:string='';
    description:string='';
    amount:number=0;
    
}
