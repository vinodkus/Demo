export class RegisterUser {
    firstName:string='';
    lastName:string='';
    email:string='';
    phone:string='';
    password:string='';
    confirmPassword:string='';  
    gender:string='';
}
