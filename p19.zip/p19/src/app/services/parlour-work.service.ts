import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Ps } from '../modules/admin/components/model/ps';


@Injectable({
  providedIn: 'root'
})
export class ParlourWorkService {
baseUrl!:string;
  constructor(private http:HttpClient) {
    this.baseUrl='http://localhost/3000/ParlourWork/'
   }
   
// addParlourWork(ps:Ps):Observable<Ps>{
//   console.log('ps -> '+JSON.stringify(ps));
//     return this.http.post<Ps>(this.baseUrl,ps);
// }
addParlourWork(ps:any){
  console.log('ps -> '+JSON.stringify(ps));
   // return this.http.post<Ps>(this.baseUrl,ps);
   return this.http.post('http://localhost/3000/ParlourWork',ps).pipe(map((res:any)=>{
    return res;
   }))
}
getAllParlourWork():Observable<Ps[]>{
  return this.http.get<Ps[]>(this.baseUrl);
}
deleteParlourWork(ps:Ps):Observable<Ps>{
  return this.http.delete<Ps>(this.baseUrl+'/'+ps.id);
}
editParlourWork(ps:Ps):Observable<Ps>{
  return this.http.put<Ps>(this.baseUrl+'/'+ps.id,ps);
}
}
