export class BillingDtl {
    id:number=0;
    billingId:number=0;
    type:string='';
    productId:number=0;
    quanity:number=0;
    subtotal:number=0;
    employeeId:number=0;
}
