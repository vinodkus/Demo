import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm = new FormGroup({
    email: new FormControl(''),
    password: new FormControl('')
  })
  constructor(private auth: AuthService, private router: Router, private http: HttpClient) { }
  ngOnInit(): void {
    if (this.auth.isLoggedIn()) {
      this.router.navigate(['admin'])
    }
  }
  onSubmit(): void {
    console.log(this.loginForm.value);
    // if (this.loginForm.valid) {
    //   this.auth.login(this.loginForm.value).subscribe((result) => {
    //     this.router.navigate(['admin']);
    //   }, (err: Error) => {
    //     alert(err.message);
    //   })
    // }
  //   this.auth.login({email:this.loginForm.value.email, password:this.loginForm.value.password})
  //   .subscribe((res)=>{
  //     var s = res;
  //     if(res)
  //     {
  //       this.loginForm.reset();
  //       this.router.navigate(['admin']); 
  //     }
  //     else{
  //       alert('Login Failed')
  //     }
  //   }, err => {
  //     alert('Something went wrong');
  //   })
  // }

    this.http.get<any>("http://localhost:3000/UserList")
      .subscribe(res => {
        const user = res.find((a: any) => {
          return a.email === this.loginForm.value.email && a.password === this.loginForm.value.password
        });
        if (user) {
          // alert('Login success')
          sessionStorage.setItem('loggedIn','vinod');
          this.loginForm.reset();
          this.router.navigate(['admin']);
        }
        else {
          alert('Login Failed')
        }
      }, err => {
        alert('Something went wrong');
      })
  }


}
